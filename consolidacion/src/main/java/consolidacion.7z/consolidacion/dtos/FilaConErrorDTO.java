package consolidacion.dtos;

public class FilaConErrorDTO {
    private int fila;
    private String motivo;

    public FilaConErrorDTO(int fila, String motivo) {
        this.fila = fila;
        this.motivo = motivo;
    }

    // Getters y Setters
}
