package consolidacion.models;

import jakarta.persistence.*;
import java.time.LocalDate;


@Entity
public class MovimientoBancario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String idReferencia;
    private LocalDate fecha;
    private String descripcion;
    private Double monto;
    private String medioPago;

    public void setFecha(LocalDate fechaLocal) {
    }

    public void setDescripcion(String descripcionStr) {
    }

    public void setMonto(Double montoValor) {
    }

    public void setMedioPago(String medioPagoStr) {
    }

    public void setIdReferencia(String s) {
    }

    // Getters y Setters
    
}
